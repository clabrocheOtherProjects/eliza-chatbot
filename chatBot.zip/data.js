const inputData = [
  ['bonjour', 'salut'],
  ['comment vas tu', 'comment ca va'],
  ['quel age tu'],
  ['heureux']
];

const replyData = [
     ['Bonjour. ', 'Salut. '],
     ['Ca va, et toi ?', 'Je ne suis qu\'un robot je ne ressent rien. '],
     ['Je n\'ai pas d\'age, je ne suis qu\'un robot. ', `J'ai ${~~(Math.random() * 10000)} ans. `],
     ['J\'aime entendre ca. ']
];
